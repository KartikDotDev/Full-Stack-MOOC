import axios from "axios";
require('dotenv').config();

const weatherKey = process.env.REACT_APP_KEY;


console.log(process.env.REACT_APP_KEY);

const baseUrl = `https://api.openweathermap.org/data/3.0`;

const getWeather =(lat, lon) => {
    const request = axios.get(`${baseUrl}/onecall?lat=${lat}&lon=${lon}&appid=${weatherKey}`);
    return request.then((response) => response);
}

const weatherService = { getWeather };

export default weatherService;