import { useEffect, useState } from "react";
import countryService from "./services/countries";
import weatherService from "./services/weather";



const CountryInfo = ({ country }) => {

  console.log(country);
  const style = {
    fontSize: "200px",
    width: "200px",
    height: "200px",

    // make the border solid red 1px
    border: "solid black 1px"

  }



  useEffect(() => {

    try {
      weatherService.getWeather(country.capitalInfo[0], country.capitalInfo[1])
        .then((data) => {
          console.log(data);
        });
    } catch (error) {
      console.log(error);
    }
  }, [country.capitalInfo]);
  

  // const [weather, setWeather] = useState({
  //   temperature: "",
  //   wind_speed: "",
  //   wind_dir: "",
  //   weather_icons: []
  // });

  // useEffect(() => {
  //   weatherService.getWeather(country.capital)
  //     .then((data) => {
  //       console.log(data);
  //       setWeather({
  //         temperature: data.current.temperature,
  //         wind_speed: data.current.wind_speed,
  //         wind_dir: data.current.wind_dir,
  //         weather_icons: data.current.weather_icons
  //       });
  //     });
  // }, [country.capital]);


  // try {
  //   const languageArray = Object.values(country.languages);
  //   console.log(languageArray);
  //   console.log(typeof country.flag);
  //   // console.log(typeof country.languages.length);
  //   // console.log(country.languages);
  //   // const languages = country.languages.forEach((language) => <li key={language}>{language}</li>);
  // } catch (error) {
  //   console.log(error);
  // }
  return (
    <>
      <h1>{country.name}</h1>
      <p>Capital: {country.capital}</p>
      <p>Population: {country.population}</p>
      <h3>Languages</h3>
      <ul>
        {Object.values(country.languages).map((language) => <li key={language}>{language}</li>)}
      </ul>
      <h3>Flag</h3>
      <span style={style}>{country.flag}</span>

      <h3>Weather in {country.capital}</h3>
      <p>Temperature: </p>
      </>
  )
}


const App = () => {
  const [countries, setCountries] = useState([]);

  const [search, setSearch] = useState("");

  const [filteredCountries, setFilteredCountries] = useState([]);

  const [country, setCountry] = useState({
    name: "",
    capital: "",
    population: "",
    languages: [],
    flag: ""
  });

  useEffect(() => {
    countryService.getAll().then((initialCountries) => {

      console.log(initialCountries);

      const temp = initialCountries.map(({ name, capital, capitalInfo, population, languages, flag }) => ({
        name: name.common,
        capital,
        capitalInfo: capitalInfo.latlng,
        population, 
        languages, 
        flag
      }));

      // console.log(temp[0].capitalInfo[0]);
      console.log(temp);
      setCountries(temp);
    });
  }, []);


  const handleSearch = (event) => {
    event.preventDefault();
    console.log(event.target.value);
    setSearch(event.target.value);
    const temp = countries.filter((country) => country.name.toLowerCase().includes(event.target.value.toLowerCase()));
    console.log(temp);
    console.log(temp.length);
    setFilteredCountries(temp);
    setCountry({
      name: "",
      capital: "",
      population: "",
      languages: [],
      flag: ""
    });
  }

  const handleShow = (country) => {  
  return () => {
    console.log(country);
    setCountry(country);
  }
}



  return (
    <>
      <h1>Country Data</h1>
      <form>
        <label htmlFor="search">Find country data </label>
        <input type="text" placeholder="Search" value={search} onChange={handleSearch} />
      </form>
      
      {(country.name === '') ? ((filteredCountries.length > 11) ? (<p>Too many matches</p>) : ( ( filteredCountries.length > 1) ? (filteredCountries.map((country, idx) =>  { return <div key={idx}><span>{country.name}</span> <button onClick={handleShow(country)}>show</button></div>})) : ((filteredCountries.length === 1)? <CountryInfo country={filteredCountries[0]}/> : (<p>No Data found</p>) ))  ) : (<CountryInfo country={country}/>) }     
    </>
  )
}

export default App;
